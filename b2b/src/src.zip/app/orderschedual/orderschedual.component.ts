import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../providers/auth.service';

@Component({
  selector: 'app-orderschedual',
  templateUrl: './orderschedual.component.html',
  styleUrls: ['./orderschedual.component.css']
})
export class OrderschedualComponent implements OnInit {

  constructor(private router : Router, private auth : AuthService) {
    if(auth.loggedIn) {
      this.router.navigate(['/']);
    } else {
      this.router.navigate(['/login']);
    }
   }

  ngOnInit() {
  }

}
