import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderschedualComponent } from './orderschedual.component';

describe('OrderschedualComponent', () => {
  let component: OrderschedualComponent;
  let fixture: ComponentFixture<OrderschedualComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderschedualComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderschedualComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
