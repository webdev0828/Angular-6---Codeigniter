import { Component, OnInit } from '@angular/core';
import { AuthService } from '../providers/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {

  constructor(private auth : AuthService, private router : Router) {
    if(auth.loggedIn) {
      this.router.navigate(['/']);
    } else {
      this.router.navigate(['/login']);
    }
   }

  ngOnInit() {
  }

}
