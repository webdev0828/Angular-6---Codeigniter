import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AuthService } from '../providers/auth.service';
import { UrlService } from '../providers/url.service';
declare var $: any;
import * as moment from 'moment';
@Component({
  selector: 'app-ordercustom',
  templateUrl: './ordercustom.component.html',
  styleUrls: ['./ordercustom.component.css']
})
export class OrdercustomComponent implements OnInit {
  closeResult: string;
  uType = ""
  onBehalf = ""
  form_data = {
    make: "",
    model: "",
    year: "",
    additional_notes: "",
    window_shades: [],
    paint: [],
    comment_to_order: "",
    delivery_address: "",
    requisition_number: "",
    salesman: []
  }
  saleman = []
  window;
  shade;
  userId;
  salesmanName;
  salesmanEmail
  salesmanPhone
  mobilPlanId;

  plannings = [];
  overAllduration = 0;
  overAllPrice = 0;
  installers = []
  weekDates = []
  singleDateData = [];
  allSlots = []
  finalSlots = []
  percentage = 80;
  previousTime: any;
  lastEndtime: any;
  endingTime = "16:00"
  employeeName = ""
  employeeId = ""
  singleSlot = {}
  innerIndex = 0;
  mainIndex = 0;
  totalSlots = []
  updated = false;
  installerNames = []
  day1 = []
  day2 = []
  day3 = []
  day4 = []
  day5 = []
  day6 = []
  makee;
  modell;
  yearr;
  rekNo;
  taskTime;
  taskDate;
  orderedBy;
  salesManName;
  salesManId;
  attachedUser;
  userAddress;
  errorMessage = false;
  errorText = ""
  successMessage = false;
  successText = ""

  fromStart;
  fromEnd;
  currentValue=0;
  dateToAddOrSubtract=0;
  currentDayName;
  weekDatesWithDate=[]
  selectedItem;
  slotError=false;
  constructor(private modalService: NgbModal, private router: Router, private auth: AuthService,
    private url: UrlService, private http: Http, private spinner: NgxSpinnerService) {
    if (auth.getLocalTokens() != null) {
      this.uType = JSON.parse(localStorage.getItem("data")).accountType;
      this.onBehalf = JSON.parse(localStorage.getItem("data")).onBehalf;
      this.orderedBy = JSON.parse(localStorage.getItem("data")).name;
      // this.userId = JSON.parse(localStorage.getItem("simulate")).userId;
    }
    if (auth.loggedIn && this.uType == "user" && this.onBehalf == "user") {
      var passwordChanged = JSON.parse(localStorage.getItem("data")).passwordChanged;
      this.userId = JSON.parse(localStorage.getItem("data")).userId;
      this.mobilPlanId = JSON.parse(localStorage.getItem("data")).mobilPlanId;
      if (passwordChanged == "no") {
        this.router.navigate(['/changepassword']);
      }
    } else if (auth.getGrantTokens() != null) {
      this.userId = JSON.parse(localStorage.getItem("simulate")).userId;
      this.mobilPlanId = JSON.parse(localStorage.getItem("simulate")).mobilPlanId;
    }
    else {
      this.router.navigate(['/login']);
    }

  }

  ngOnInit() {
    $(document).ready(function() {
      // Toolbar extra buttons
      var btnFinish = $('<button></button>').text('Finish')
      .addClass('btn btn-info btn-finish')
      .css("display","none")
      .on('click', function() {
      // var elmForm = $("#myForm");
       elmForm.submit();
       $('.btn-finish').addClass('disabled');
      //  return false;
          if (!$(this).hasClass('disabled')) {
              var elmForm = $("#myForm");

             // return false;
              if (elmForm) {
                  elmForm.validator('validate');
                  var elmErr = elmForm.find('.has-error');
                  if (elmErr && elmErr.length > 0) {
                      alert('Please fill out the required fields');
                      return false;
                  } else {
                      //alert('Great! we are ready to submit form');
                      elmForm.submit();
                      $('.btn-finish').addClass('disabled');
                      return false;
                  }
              }
          }
      });
  var btnCancel = $('<button></button>').text('Cancel')
      .addClass('btn btn-danger')
      .on('click', function() {
          $('#smartwizard').smartWizard("reset");
          $('#myForm').find("input, textarea").val("");
      });



  // Smart Wizard
  $('#smartwizard').smartWizard({
      selected: 0,
      theme: 'dots',
      transitionEffect: 'fade',
      toolbarSettings: {
          toolbarPosition: 'bottom',
          toolbarExtraButtons: [btnFinish]
      }
  });


  $("#smartwizard").on("leaveStep", function(e, anchorObject, stepNumber, stepDirection) {
      var elmForm = $("#form-step-" + stepNumber);
      // stepDirection === 'forward' :- this condition allows to do the form validation
      // only on forward navigation, that makes easy navigation on backwards still do the validation when going next
      if (stepDirection === 'forward' && elmForm) {
          elmForm.validator('validate');
          var elmErr = elmForm.children('.has-error');
          if (elmErr && elmErr.length > 0) {
              // Form validation failed
              return true;
          }
      }
      return true;
  });

  $("#smartwizard").on("showStep", function(e, anchorObject, stepNumber, stepDirection) {
    $("html, body").animate({ scrollTop: 0 }, "slow");
      // Enable finish button only on last step
      if (stepNumber == 2) {
        $(".sw-btn-next").css("display","none")
        $(".btn-finish").css("display","block")
         $('.btn-finish').removeClass('disabled');
      } else {
        $(".sw-btn-next").css("display","block")
          $(".btn-finish").css("display","none")
          $('.btn-finish').addClass('disabled');
      }
  });
});
    this.downloadCustomer();
  }
  j = 0;
  all = []


  downloadCustomer() {
    this.spinner.show()
    this.form_data.salesman = []
    var params = "?customerId=" + this.userId
    this.http.get(this.url.SOLFILM_URL + "salesman/" + params)
      .subscribe((data: Response) => {
        const d = data.json();
        if (d.status == "success") {
          this.saleman = d.data;
          this.spinner.hide()
        } else {
          this.spinner.hide()
        }
      })

    var params = "?autoDealerId=" + this.mobilPlanId;
    this.http.get(this.url.APP_URL + "plannings" + params)
      .subscribe((data: Response) => {
        const d = data.json();
        if (d.status == "success") {
          this.plannings = d.data;
          this.installers = d.installers;
          this.weekDates = d.dates;
          this.weekDatesWithDate= d.datesWithNames;
          this.installerNames = d.installerNames;
          for (var a = 0; a < this.weekDates.length; a++) {

            this.singleDateData = this.plannings[this.weekDates[a]];

            this.j = 0;
            var x = 0;
            this.installers.forEach(element => {

              if (this.singleDateData[element]) {
                this.all[x] = this.makeSlots(this.singleDateData[element],this.weekDates[a]);
              } else {
                if (a < 5) {
                  var completeDatSlot=[]
                  var startDate = this.weekDates[a] + " " + "08:00";
               var endDate = this.weekDates[a] + " " + "16:00";
               const formData = new FormData();
               formData.append('startDate', startDate);
               formData.append('endDate', endDate);
               this.http.post(this.url.APP_URL+"renderDates",formData).subscribe((donme: Response) => {
                 const res = donme.json()
                 var percentage = 100/res.percentage;
                 res.data.forEach(element1 => {


                  var singleSlot = {}
                  singleSlot['sl'] = percentage
                  singleSlot['empName'] = this.employeeName
                  singleSlot['empId'] = element
                  singleSlot['time'] = element1.time
                  singleSlot['status'] = "free"
                  completeDatSlot.push(singleSlot)
                 });
               })
               this.all[x] = completeDatSlot;
                 // let userTestStatus = [
                 //   { "sl": 100, "empName": this.installerNames[x], "empId": element, "status": "free", time: "08:00 - 16:00" },
                 // ];
                 // this.all[x] = userTestStatus
                }
              }
              x++;
            });
            this.finalSlots[a] = this.all
            this.all = []
          }
          var obj = {}
          obj['status'] = "closed"
          this.finalSlots[5] = obj
          this.finalSlots[6] = obj

          this.day1 = this.finalSlots[0]
          this.day2 = this.finalSlots[1]
          this.day3 = this.finalSlots[2]
          this.day4 = this.finalSlots[3]
          this.day5 = this.finalSlots[4]

        } else {
          this.errorMessage = true;
          this.errorText="Error Occurred. Please try again."
          this.spinner.hide();
        }
      })
  }
  slotsIndex = 0;

  makeSlots(employee,currentDAte) {
    this.allSlots = []
    this.employeeName = ""
    this.employeeId = ""

    for (var e = 0; e <= employee.length; e++) {
      if (e < employee.length) {
        if (e < 1) {
          this.employeeName = employee[e].employeeName
          this.employeeId = employee[e].employeeId
          var diffSplit = employee[e].busy.split("-");
          var startTime = diffSplit[0]
          var sTime = startTime.replace(":", ".")
          var endTime = diffSplit[1]
          this.previousTime = endTime;
          this.lastEndtime = endTime;
          var eTime = endTime.replace(":", ".")
          if(sTime.toString().trim() == '08.00') {
          var diff = parseFloat(eTime) - parseFloat(sTime);
          if(diff > 0) {

          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = employee[e].employeeName
          singleSlot['empId'] = employee[e].employeeId
          singleSlot['time'] = startTime + "-" + endTime
          singleSlot['status'] = "busy"
          this.allSlots.push(singleSlot)
          }
        }
        if(sTime.toString().trim() != '08.00') {

          var sTimee = '08.00';

          var diff = parseFloat(eTime) - parseFloat(sTimee);
          if(diff > 0) {

          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = employee[e].employeeName
          singleSlot['empId'] = employee[e].employeeId
          singleSlot['time'] = '08-00' + "-" + startTime
          singleSlot['status'] = "free"
          this.allSlots.push(singleSlot)

          }


          var diff = parseFloat(eTime) - parseFloat(sTime);
          if(diff > 0) {

          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = employee[e].employeeName
          singleSlot['empId'] = employee[e].employeeId
          singleSlot['time'] = startTime + "-" + endTime
          singleSlot['status'] = "busy"
          this.allSlots.push(singleSlot)
          }
        }


        } else {
          if (employee[e]) {
            var diffSplit = employee[e].busy.split("-");
            var startTime = this.previousTime
            var sTime = startTime.replace(":", ".")
            var endTime = diffSplit[0]
            var eTime = endTime.replace(":", ".")
            var diff = parseFloat(eTime) - parseFloat(sTime);

            if (diff > 0) {
              var singleSlot = {}
              var d = diff / this.percentage;
              var slotPercentage = d * 100;
              var slot = slotPercentage * 10;
              var s = slot.toFixed(2)

              singleSlot['sl'] = s
              singleSlot['empName'] = employee[e].employeeName
              singleSlot['empId'] = employee[e].employeeId
              singleSlot['time'] = startTime + "-" + endTime
              singleSlot['status'] = "free"
              this.allSlots.push(singleSlot)

            }

            var diffSplit = employee[e].busy.split("-");
            var startTime = diffSplit[0]
            var sTime = startTime.replace(":", ".")
            var endTime = diffSplit[1]
            this.previousTime = endTime;
            this.lastEndtime = endTime;
            var eTime = endTime.replace(":", ".")
            var diff = parseFloat(eTime) - parseFloat(sTime);
            var d = diff / this.percentage;
            var slotPercentage = d * 100;
            var slot = slotPercentage * 10;
            var s = slot.toFixed(2)
            var singleSlot = {}
            singleSlot['sl'] = s
            singleSlot['empName'] = employee[e].employeeName
            singleSlot['empId'] = employee[e].employeeId
            singleSlot['time'] = startTime + "-" + endTime
            singleSlot['status'] = "busy"
            this.allSlots.push(singleSlot)
          } else {
            var startTime = this.lastEndtime;
            var sTime = startTime.replace(":", ".");
            var endTime: any = this.endingTime;
            var diff = parseFloat(endTime) - parseFloat(sTime);
            var d = diff / this.percentage;
            var slotPercentage = d * 100;
            var slot = slotPercentage * 10;
            var s = slot.toFixed(2)
            var singleSlot = {}
            singleSlot['sl'] = s
            singleSlot['empName'] = this.employeeName
            singleSlot['empId'] = this.employeeId
            singleSlot['time'] = startTime + "-" + endTime
            singleSlot['status'] = "free"
            this.allSlots.push(singleSlot)
          }
        }
      } else {
        var startTime = this.lastEndtime;
        var ssTime = startTime.replace(":", ".");
        var sTime = ssTime.replace(" ", "")
        var endTime: any = this.endingTime;
        var eTime = endTime.replace(":", ".")
        if (sTime < eTime) {
          var diff = parseFloat(eTime) - parseFloat(sTime);
          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = this.employeeName
          singleSlot['empId'] = this.employeeId
          singleSlot['time'] = startTime + "-" + endTime
          singleSlot['status'] = "free"
          this.allSlots.push(singleSlot)
        }
      }

    }
    return this.allSlots
  }

  open(content) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  submit= 0;
  OrderCustom(form) {
    if(this.slotError == false && this.overAllPrice >0) {
    if(this.submit==0) {

    const formData = new FormData();
    formData.append('custom_ordered_by', this.orderedBy);
    formData.append('custom_their_ref_name', this.salesManName);
    formData.append('custom_invoice_text', "");
    formData.append('custom_montage_address_if_different_from_customer', this.userAddress);
    formData.append('custom_rekv', this.rekNo);
    formData.append('customer_no', this.mobilPlanId);
    formData.append('title', "Project " + this.makee + " " + this.modell);
    formData.append('place', "");
    formData.append('content', "");
    formData.append('notes', "");
    formData.append('custom_hex_color', "");
    formData.append('start_date', this.taskDate + " " + this.fromStart);
    formData.append('end_date', this.taskDate + " " + this.fromEnd);
    formData.append('attached_users_csv', this.attachedUser);
    formData.append('estimated_minutes', this.overAllduration.toString());
    formData.append('user_id', this.mobilPlanId);
    formData.append('project_id', "");
    formData.append('from', this.taskDate + " " + this.fromStart);
    formData.append('to', this.taskDate + " " + this.fromEnd);
    formData.append('comment', "");
    //to save in our database
    formData.append('model', this.makee + " " + this.modell + "," + this.yearr);
    formData.append('windows', JSON.stringify(this.form_data.window_shades));
    formData.append('scheduledTime', this.taskDate + " " + this.taskTime);
    formData.append('price', this.overAllPrice.toString());
    formData.append('userId', this.userId);
    formData.append('bDate', this.taskDate + " " + this.fromStart + "-" + this.fromEnd);
      this.spinner.show()
    this.http.post(this.url.APP_URL + "addProject", formData)
      .subscribe((customerAdded: Response) => {
        const res = customerAdded.json()
        if (res.status == "success") {
          this.errorMessage= false;
          this.successMessage = true;
          this.successText = ""
          this.successText = "Order Placed successfully";
          var _this = this;
          setTimeout(function () {
            _this.spinner.hide()
            _this.router.navigate(['/']);
          }, 3000);
        }
      });
      $('.btn-finish').addClass('disabled');
    this.submit++;
    }
  } else {
    this.errorMessage = true;
    this.errorText = ""
    this.errorText="Please select free slot or add/select any material first";
  }

  }
  onChangeCustomer(value) {
    this.slotError=false;
    var v = value.split("_");
    var cId = v[0];
    var cName = v[1];
    var salesman = {
      cId: cId,
      cName: cName
    }

    if (this.form_data.salesman.filter(item => item.cId == cId).length == 0) {
      this.salesManName = salesman.cName
      this.salesManId = salesman.cId
      this.form_data.salesman.push(salesman);
    }

  }

  onChangePaint(value, isChecked: boolean) {
    this.slotError=false;
    this.errorMessage=false;
    var splitData = value.split("_");
    var paintType = {
      price: splitData[0],
      duration: splitData[1],
      "pType": splitData[2]
    }
    if (isChecked) {
      if (this.form_data.paint.filter(item => item.pType == paintType.pType).length == 0) {
        this.overAllPrice = this.overAllPrice + parseInt(paintType.price)
        this.overAllduration = this.overAllduration + parseInt(paintType.duration)

        this.form_data.paint.push(paintType);
      }
    }
    else {
      this.overAllPrice = this.overAllPrice - parseInt(paintType.price);
      this.overAllduration = this.overAllduration - parseInt(paintType.duration);
      let index = this.form_data.paint.indexOf(value);
      this.form_data.paint.splice(index, 1);
    }
  }

  SaveWindows(windows) {
    this.slotError=false;
    this.errorMessage=false;
    var spliData = windows.window.split("_");

    var record = {
      shade: windows.shade,
      price: spliData[0],
      duration: spliData[1],
      window: spliData[2]
    }
    if (this.form_data.window_shades.filter(item => item.shade == record.shade && item.window == record.window).length == 0) {
      this.overAllPrice = this.overAllPrice + parseInt(spliData[0]);
      this.overAllduration = this.overAllduration + parseInt(spliData[1]);
      this.form_data.window_shades.push(record);
    }
    this.modalService.dismissAll()
  }
  deleteWindow(index, value) {
    this.overAllPrice = this.overAllPrice - parseInt(value.price);
    this.overAllduration = this.overAllduration - parseInt(value.duration);
    this.form_data.window_shades.splice(index, 1)

  }
  SaveCustomer(customer) {
    const formData = new FormData();
    formData.append('name', customer.salesmanName);
    formData.append('email', customer.salesmanEmail);
    formData.append('phone', customer.salesmanPhone);
    formData.append('mobilPlanId', this.mobilPlanId);
    formData.append('customerId', this.userId);
    this.http.post(this.url.SOLFILM_URL + 'addCustomer', formData)
      .subscribe((customerAdded: Response) => {
        const res = customerAdded.json()
        if (res.status == "success") {
          this.saleman = res.data;
          this.saleman.reverse()
          this.modalService.dismissAll()
        }
      });
  }
  hou;
  min;
  daySlot(index, slot,Day) {
    this.errorMessage=false;
    this.slotError=false
    this.selectedItem = slot;
    this.currentDayName = Day;
    if(index === 5) {
      $("html, body").animate({ scrollTop: 0 }, "slow");
      this.errorMessage = true;
      this.errorText = ""
      this.errorText = "Selected days are closed."
      return false;
    }
    if (this.overAllduration > 0) {
      if (slot.status == "free") {
        var time = slot.time;
        var splitTime = time.split("-")
        var startTime = splitTime[0]
        var durtion = this.overAllduration
        this.taskDate = this.weekDates[index]
        this.attachedUser = slot.empId
        var varDate = new Date(this.taskDate);
        var today = new Date();
        today.setHours(0,0,0,0);
        if(varDate < today) {
          $("html, body").animate({ scrollTop: 0 }, "slow");
          this.errorMessage = true;
          this.errorText = ""
          this.errorText = "You can not select previous date slot"
          this.slotError=true;
        }


        var hours: any = durtion / 60;
        if (hours.toString().indexOf(".") !== -1) {
          var ho = hours.toString().split(".");
          this.hou = ho[0]
          this.min = ho[1]
        } else {
          this.hou = hours
        }
        var hoursSplit = startTime.split(":")
        var h = hoursSplit[0]
        var min = hoursSplit[1]
        var fHpours = parseFloat(h) + parseFloat(this.hou)
        var Minutes = hours * 60;

        if (Minutes > 60) {
          var fMin = Minutes - 60;
        } else {
          var fMin = Minutes;
        }

        if (fMin == 60) {
          var mints = "00:00";
        } else {
          var mints = fMin.toString() + ":00";
        }
        if (fHpours < 10) {
          var hrs = "0" + fHpours
        } else {
          var hrs = fHpours.toString();
        }
        var endDate =  moment.utc(startTime.toString().trim(),'H:mm').add(durtion,'minutes').format('HH:mm:ss');
        var endSplit = endDate.toString().replace(":",".");
        var eTime = "16.00";
        if(endSplit > eTime) {
          $("html, body").animate({ scrollTop: 0 }, "slow");
          this.slotError=true;
          this.errorMessage = true;
          this.errorText = ""
          this.errorText = "Slot time is less than selected material time. Please select any other slot."
        }
        this.errorMessage=false
        this.slotError=false;

        this.taskTime = startTime.toString().trim() + ":00" + " - " + endDate
        this.fromStart = ""
        this.fromEnd = ""
        this.fromStart = startTime.toString().trim() + ":00";
        this.fromEnd = endDate;
        // this.taskTime = startTime.toString().trim() + ":00" + " - " + hrs + ":" + mints
        // this.fromStart = ""
        // this.fromEnd = ""
        // this.fromStart = startTime.toString().trim() + ":00";
        // this.fromEnd = hrs + ":" + mints;

      } else {
        $("html, body").animate({ scrollTop: 0 }, "slow");
        this.errorMessage = true;
        this.slotError=true;
        this.errorText = ""
        this.errorText = "Please select a free time slot"
      }
    } else {
      $("html, body").animate({ scrollTop: 0 }, "slow");
      this.errorMessage = true;
      this.slotError=true;
      this.errorText = ""
      this.errorText = "Please Select any material first"
    }
  }
  onchangeDay(value) {
    if(value == "fixed") {
      this.overAllPrice = this.overAllPrice + 300;
    }
  }
  make(value) {
    this.makee = value;
  }
  model(value) {
    this.modell = value;
  }
  year(value) {
    this.yearr = value;
  }
  rek(value) {
    this.rekNo = value;
  }

  deliveryAddress(value) {
    this.userAddress = value;
  }
  nextDate;
    previous() {
      if(this.currentValue == 0) {
        this.errorMessage=true;
        this.errorText = "You can not go back from to previous date slots"
      }
      if(this.currentValue > 0) {

        this.errorMessage=false;
        this.currentValue = this.currentValue-1;

        if(this.dateToAddOrSubtract > 7) {
          this.dateToAddOrSubtract = this.dateToAddOrSubtract - 7;
        }
        if(this.dateToAddOrSubtract == 7) {
          this.dateToAddOrSubtract = 7;
        }
        this.plannings=[]
        this.installerNames=[]
        this.weekDates=[]
        this.installers=[]
        this.singleDateData = []
        this.all=[]
        this.finalSlots=[]
        this.day1=[]
        this.day2=[]
        this.day3=[]
        this.day4=[]
        this.day5=[]
        this.day6=[]
        this.allSlots=[]
        this.weekDatesWithDate=[]

        var params = "?autoDealerId=" + this.mobilPlanId+"&incValue="+this.dateToAddOrSubtract+"&type=previous&date="+this.nextDate;
        this.spinner.show()
        this.http.get(this.url.APP_URL + "planningnextprevious" + params).subscribe((data: Response) => {
            const d = data.json();
            if (d.status == "success") {
              this.plannings = d.data;
              this.installers = d.installers;
              this.weekDates = d.dates;
              this.weekDatesWithDate= d.datesWithNames;
              this.installerNames = d.installerNames;
              this.nextDate=this.weekDates[0]

              for (var a = 0; a < this.weekDates.length; a++) {
                this.singleDateData = this.plannings[this.weekDates[a]];
                this.j = 0;
                var x = 0;
                this.installers.forEach(element => {
                  if (this.singleDateData[element]) {
                    this.all[x] = this.makeSlots(this.singleDateData[element],this.weekDates[a]);
                  } else {
                    if (a < 5) {
                      var completeDatSlot=[]
                       var startDate = this.weekDates[a] + " " + "08:00";
                    var endDate = this.weekDates[a] + " " + "16:00";
                    const formData = new FormData();
                    formData.append('startDate', startDate);
                    formData.append('endDate', endDate);
                    this.http.post(this.url.APP_URL+"renderDates",formData).subscribe((donme: Response) => {
                      const res = donme.json()
                      var percentage = 100/res.percentage;
                      res.data.forEach(element => {
                        var singleSlot = {}
                        singleSlot['sl'] = percentage
                        singleSlot['empName'] = this.employeeName
                        singleSlot['empId'] = this.employeeId
                        singleSlot['time'] = element.time
                        singleSlot['status'] = "free"
                        completeDatSlot.push(singleSlot)
                      });
                    })
                    this.all[x] = completeDatSlot;
                    }
                  }
                  x++;
                });
                this.finalSlots[a] = this.all
                this.all = []
              }
              var obj = {}
              obj['status'] = "closed"
              this.finalSlots[5] = obj
              this.finalSlots[6] = obj
              this.day1 = this.finalSlots[0]
              this.day2 = this.finalSlots[1]
              this.day3 = this.finalSlots[2]
              this.day4 = this.finalSlots[3]
              this.day5 = this.finalSlots[4]
             this.spinner.hide()
            }
          })
      }
    }

    next() {
      this.errorMessage=false;
      this.currentValue++;
      this.dateToAddOrSubtract = this.dateToAddOrSubtract + 7;
      this.plannings=[]
      this.installerNames=[]
      this.weekDates=[]
      this.installers=[]
      this.singleDateData = []
      this.all=[]
      this.finalSlots=[]
      this.day1=[]
      this.day2=[]
      this.day3=[]
      this.day4=[]
      this.day5=[]
      this.day6=[]
      this.allSlots=[]
      this.weekDatesWithDate=[]

      var params = "?autoDealerId=" + this.mobilPlanId+"&incValue="+this.dateToAddOrSubtract+"&type=next&date=''";
      this.spinner.show()
      this.http.get(this.url.APP_URL + "planningnextprevious" + params).subscribe((data: Response) => {
          const d = data.json();
          if (d.status == "success") {
            this.plannings = d.data;
            this.installers = d.installers;
            this.weekDates = d.dates;
            this.weekDatesWithDate= d.datesWithNames;
            this.nextDate=this.weekDates[0]
            this.installerNames = d.installerNames;
            for (var a = 0; a < this.weekDates.length; a++) {
              this.singleDateData = this.plannings[this.weekDates[a]];
              this.j = 0;
              var x = 0;
              this.installers.forEach(element => {
                if (this.singleDateData[element]) {
                  this.all[x] = this.makeSlots(this.singleDateData[element],this.weekDates[a]);
                } else {
                  if (a < 5) {
                    var completeDatSlot=[]
                     var startDate = this.weekDates[a] + " " + "08:00";
                  var endDate = this.weekDates[a] + " " + "16:00";
                  const formData = new FormData();
                  formData.append('startDate', startDate);
                  formData.append('endDate', endDate);
                  this.http.post(this.url.APP_URL+"renderDates",formData).subscribe((donme: Response) => {
                    const res = donme.json()
                    var percentage = 100/res.percentage;
                    res.data.forEach(element => {
                      var singleSlot = {}
                      singleSlot['sl'] = percentage
                      singleSlot['empName'] = this.employeeName
                      singleSlot['empId'] = this.employeeId
                      singleSlot['time'] = element.time
                      singleSlot['status'] = "free"
                      completeDatSlot.push(singleSlot)
                    });
                  })
                  this.all[x] = completeDatSlot;
                  }
                }
                x++;
              });
              this.finalSlots[a] = this.all
              this.all = []
            }
            var obj = {}
            obj['status'] = "closed"
            this.finalSlots[5] = obj
            this.finalSlots[6] = obj
            this.day1 = this.finalSlots[0]
            this.day2 = this.finalSlots[1]
            this.day3 = this.finalSlots[2]
            this.day4 = this.finalSlots[3]
            this.day5 = this.finalSlots[4]
           this.spinner.hide()
          }
        })

    }

}
