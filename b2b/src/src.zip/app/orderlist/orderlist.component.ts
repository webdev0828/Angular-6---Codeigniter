import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import { AuthService } from '../providers/auth.service';
import { UrlService } from '../providers/url.service';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-orderlist',
  templateUrl: './orderlist.component.html',
  styleUrls: ['./orderlist.component.css']
})
export class OrderlistComponent implements OnInit {
  closeResult: string;
  uType=""
  onBehalf=""
  orderedBy;
  userId;
  mobilPlanId;
  ordrList=[]
  cancellationMessage;
  bookingId;
  cancellationDiv = false;
  cancellationMessageValue;
  price=0;
  projectId;
  constructor(private modalService: NgbModal, private router : Router, private auth : AuthService, private url : UrlService,
    private http : Http, private spinner: NgxSpinnerService) {
      if (auth.getLocalTokens() != null) {
        this.uType = JSON.parse(localStorage.getItem("data")).accountType;
        this.onBehalf = JSON.parse(localStorage.getItem("data")).onBehalf;
        this.orderedBy = JSON.parse(localStorage.getItem("data")).name;
       // this.userId = JSON.parse(localStorage.getItem("simulate")).userId;
      }
      if (auth.loggedIn && this.uType == "user" && this.onBehalf == "user") {
        var passwordChanged = JSON.parse(localStorage.getItem("data")).passwordChanged;
        this.userId = JSON.parse(localStorage.getItem("data")).userId;
        this.mobilPlanId = JSON.parse(localStorage.getItem("data")).mobilPlanId;
        this.orderedBy = JSON.parse(localStorage.getItem("data")).name;
        if (passwordChanged == "no") {
          this.router.navigate(['/changepassword']);
        }
      } else if (auth.getGrantTokens() != null) {
        this.userId = JSON.parse(localStorage.getItem("simulate")).userId;
        this.orderedBy = JSON.parse(localStorage.getItem("simulate")).name;
      }
      else {
        this.router.navigate(['/login']);
      }
  }

  ngOnInit() {
    var params = "?userId=" + this.userId
    this.http.get(this.url.APP_URL + "getOrders/" + params)
      .subscribe((data: Response) => {
        const d = data.json();
        if (d.status == "success") {
          this.ordrList = d.data;
          this.ordrList.reverse()
          this.spinner.hide()
        }
      })

  }
  open(booking,content,type) {
    this.bookingId=""
    this.projectId=""
    if(type == "cancel") {
    this.price=0
    this.cancellationDiv=false;
    this.cancellationMessageValue=""
    this.bookingId = booking.bookingId;
    var orderdate = booking.orderDate;
    var splitData = orderdate.split("-");
    var date = splitData[0]+"-"+splitData[1]+"-"+splitData[2]
    var todaydate : any = new Date(); // Current date now.
    var orderDate : any = new Date(date);
    var res : any = (orderDate - todaydate) / 1000;

    var hours : any = (res / 3600) % 24;
    var finalRes = hours.toString().split(".")
    var finalHours = parseInt(finalRes) - 2;
    var cancellationPrice : any =200;
    if(finalHours > booking.threshold) {
    }
    if(finalHours < booking.threshold) {
      if(finalHours < 0) {
        this.cancellationDiv = true;
        this.cancellationMessageValue = "You are cancelling booking for previous time. Cancellation fee will be applied"
        this.price = parseInt(booking.price) + parseInt(cancellationPrice);
      }
      if(finalHours >= 0 && finalHours <= 2) {
        this.cancellationDiv = true;
        this.cancellationMessageValue = "Cancellation Fee will be applied."
        this.price = parseInt(booking.price) + parseInt(cancellationPrice);
      }
    }
   this.cancellationMessage = ""
  } else {
    this.bookingId = booking.bookingId;
    this.projectId = booking.projectId;
  }
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  sendCancelNotes(form) {
   if(this.cancellationMessage === "") {
     this.cancellationDiv = true;
     this.cancellationMessageValue = ""
     this.cancellationMessageValue = "Please add notes";
     return false;
   }
   const formData = new FormData()
   formData.set("bookingId",this.bookingId)
   formData.set("message",this.cancellationMessage)
   formData.set("userId",this.userId)
   formData.set("price",this.price.toString())

   this.http.post(this.url.APP_URL+ "cancelBooking",formData)
   .subscribe((data: Response) => {
    const d = data.json();
    if (d.status == "success") {
      this.ordrList = []
      this.ordrList = d.data;
      this.ordrList.reverse()
      this.modalService.dismissAll()
    }
  })
  }

  sendChangeRequest(form) {
    this.router.navigate(['/reschedule',this.bookingId,this.projectId,this.userId]);
    this.modalService.dismissAll()
  }
}
