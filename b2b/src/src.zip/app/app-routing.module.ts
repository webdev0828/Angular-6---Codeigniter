import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OrderComponent } from './order/order.component';
import { LoginComponent } from './login/login.component';
import { ChangePasswordComponent} from './change-password/change-password.component';
import { EmployeesComponent} from './employees/employees.component';
import { ForgotpasswordComponent} from './forgotpassword/forgotpassword.component';
import { OrderconfirmationComponent} from './orderconfirmation/orderconfirmation.component';
import { OrdercustomComponent} from './ordercustom/ordercustom.component';
import { OrdercustomdialogComponent} from './ordercustomdialog/ordercustomdialog.component';
import { OrderlistComponent} from './orderlist/orderlist.component';
import { OrderschedualComponent} from './orderschedual/orderschedual.component';
import { RatesComponent} from './rates/rates.component';
import { UseradminComponent} from './useradmin/useradmin.component';
import { ValidationComponent} from './validation/validation.component';
import { StepperComponent } from './stepper/stepper.component';
import { EmailtemplateComponent } from './emailtemplate/emailtemplate.component';
import { RescheduleComponent } from './reschedule/reschedule.component';
import { ForgetComponent } from './forget/forget.component';

const routes: Routes = [
  {
    path: '',
    component: OrderlistComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'changepassword',
    component: ChangePasswordComponent
  },
  {
    path: 'employees',
    component: EmployeesComponent
  },
  {
    path: 'forgotpassword',
    component: ForgotpasswordComponent
  },
  {
    path: 'orderconfirmation',
    component: OrderconfirmationComponent
  },
  {
    path: 'ordercustom',
    component: OrdercustomComponent
  },
  {
    path: 'ordercustomdialog',
    component: OrdercustomdialogComponent
  },
  {
    path: 'order',
    component: StepperComponent
  },
  {
    path: 'orderschedual',
    component: OrderschedualComponent
  },
  {
    path: 'rates',
    component: RatesComponent
  },
  {
    path: 'validation',
    component: ValidationComponent
  },
  {
    path: 'stepper',
    component: StepperComponent
  },
  {
    path: 'admin',
    component: UseradminComponent
  },
  {
    path: 'email',
    component: EmailtemplateComponent
  },
  {
    path : 'reschedule/:id/:id1/:id2',
    component : RescheduleComponent
  },
  {
    path : 'forget/:id',
    component : ForgetComponent
  }

];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }
