import { Component, OnInit } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import * as $ from 'jquery';
import { AuthService } from '../providers/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { UrlService } from '../providers/url.service';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { NgxSpinnerService } from 'ngx-spinner';
declare var $: any;
import * as moment from 'moment';
@Component({
  selector: 'app-reschedule',
  templateUrl: './reschedule.component.html',
  styleUrls: ['./reschedule.component.css']
})
export class RescheduleComponent implements OnInit {
  closeResult: string;
  isChecked;
  isChecked1;
  window = false;
  paint = false;
  uType = ""
  onBehalf = ""

  plannings = [];
  overAllduration = 0;
  overAllPrice = 0;
  installers = []
  weekDates = []
  singleDateData = [];
  allSlots = []
  finalSlots = []
  percentage = 80;
  previousTime: any;
  lastEndtime: any;
  endingTime = "16:00"
  employeeName = ""
  employeeId = ""
  singleSlot = {}
  innerIndex = 0;
  mainIndex = 0;
  totalSlots = []
  updated = false;
  installerNames = []
  day1 = []
  day2 = []
  day3 = []
  day4 = []
  day5 = []
  day6 = []
  orderedBy=""
  userId;
  mobilPlanId;
  makee;
  modell;
  yearr;
  rekNo;
  taskTime;
  taskDate;
  salesManName;
  salesManId;
  attachedUser;
  userAddress;
  errorMessage = false;
  errorText = ""
  successMessage = false;
  successText = ""

  fromStart;
  fromEnd;
  ModelPrice = 0
  ModelDuration = 0
  shades = ""
  edges = ""
  bookingId;
  projectId;
  threshold;
  attachUserDB;
  price=0;
  currentValue=0;
  dateToAddOrSubtract=0;
  currentDayName;
  weekDatesWithDate=[]
  selectedItem;
  constructor(private modalService: NgbModal, private router: Router, private auth: AuthService,
    private url: UrlService, private http: Http, private spinner: NgxSpinnerService, private route : ActivatedRoute) {

      this.route.params.subscribe( params => {
        this.bookingId = params.id;
        this.projectId = params.id1;
      });
      if (auth.getLocalTokens() != null) {
        this.uType = JSON.parse(localStorage.getItem("data")).accountType;
        this.onBehalf = JSON.parse(localStorage.getItem("data")).onBehalf;
        this.orderedBy = JSON.parse(localStorage.getItem("data")).name;
        //  this.userId = JSON.parse(localStorage.getItem("simulate")).userId;
      }
      if (auth.loggedIn && this.uType == "user" && this.onBehalf == "user") {

        var passwordChanged = JSON.parse(localStorage.getItem("data")).passwordChanged;
        this.userId = JSON.parse(localStorage.getItem("data")).userId;
        this.mobilPlanId = JSON.parse(localStorage.getItem("data")).mobilPlanId;
        if (passwordChanged == "no") {
          this.router.navigate(['/changepassword']);
        }
      } else if (auth.getGrantTokens() != null) {
        this.userId = JSON.parse(localStorage.getItem("simulate")).userId;
        this.mobilPlanId = JSON.parse(localStorage.getItem("data")).mobilPlanId;
      }
      else {
        this.router.navigate(['/login']);
      }
     }

     j = 0;
     all = []
     startingTime;
     finalHours;
  ngOnInit() {
    const formData = new FormData();
    formData.set("bookingId",this.bookingId);
    formData.set("projectId",this.projectId);
    this.http.post(this.url.APP_URL + "getBooking" , formData).subscribe((data: Response) => {
      const d = data.json();
      if (d.status == "success") {
        this.mobilPlanId = d.data.mobilPlandId;
        this.overAllPrice = d.data.price;
        this.overAllduration = d.data.time;
        this.taskDate = d.data.orderDate;
        this.threshold = d.data.threshold;
        var orderdate = d.data.orderDate;
        this.attachUserDB = d.project.attached_users_csv;
        var splitData = orderdate.split("-");

        var date = splitData[0]+"-"+splitData[1]+"-"+splitData[2]
        var splittedDate = splitData[2].split(":");
        var sTime = splittedDate[0].split(" ");
        this.startingTime = sTime[1]+".00"
        var todaydate : any = new Date(); // Current date now.
        var orderDate : any = new Date(date);
        var res : any = (orderDate - todaydate) / 1000;

        var hours : any = (res / 3600) % 24;
        var finalRes = hours.toString().split(".")
        this.finalHours = parseInt(finalRes) - 2;

      }
      });
    var params = "?autoDealerId=" + this.mobilPlanId;
    this.spinner.show()
    this.http.get(this.url.APP_URL + "plannings" + params).subscribe((data: Response) => {
        const d = data.json();
        if (d.status == "success") {
          this.plannings = d.data;
          this.installers = d.installers;
          this.weekDates = d.dates;
          this.installerNames = d.installerNames;
          this.weekDatesWithDate= d.datesWithNames;


          for (var a = 0; a < this.weekDates.length; a++) {
            this.singleDateData = this.plannings[this.weekDates[a]];
            this.j = 0;
            var x = 0;
            this.installers.forEach(element => {
              if (this.singleDateData[element]) {
                this.all[x] = this.makeSlots(this.singleDateData[element],this.weekDates[a]);
              } else {
                if (a < 5) {
                  var completeDatSlot=[]
                   var startDate = this.weekDates[a] + " " + "08:00";
                var endDate = this.weekDates[a] + " " + "16:00";
                const formData = new FormData();
                formData.append('startDate', startDate);
                formData.append('endDate', endDate);
                this.http.post(this.url.APP_URL+"renderDates",formData).subscribe((donme: Response) => {
                  const res = donme.json()
                  var percentage = 100/res.percentage;
                  res.data.forEach(element => {
                    var singleSlot = {}
                    singleSlot['sl'] = percentage
                    singleSlot['empName'] = this.employeeName
                    singleSlot['empId'] = this.employeeId
                    singleSlot['time'] = element.time
                    singleSlot['status'] = "free"
                    completeDatSlot.push(singleSlot)
                  });
                })
                this.all[x] = completeDatSlot;
                  // let userTestStatus = [
                  //   { "sl": 100, "empName": this.installerNames[x], "empId": element, "status": "free", time: "08:00 - 16:00" },
                  // ];
                  // this.all[x] = userTestStatus
                }
              }
              x++;
            });
            this.finalSlots[a] = this.all
            this.all = []
          }
          var obj = {}
          obj['status'] = "closed"
          this.finalSlots[5] = obj
          this.finalSlots[6] = obj
          this.day1 = this.finalSlots[0]
          this.day2 = this.finalSlots[1]
          this.day3 = this.finalSlots[2]
          this.day4 = this.finalSlots[3]
          this.day5 = this.finalSlots[4]
          this.spinner.hide()
        } else {
          this.errorMessage = true;
          this.errorText="Error Occurred. Please try again."
          this.spinner.hide();
        }
      })
  }

  slotsIndex = 0;
  makeSlots(employee, currentDAte) {

    this.allSlots = []
    this.employeeName = ""
    this.employeeId = ""

    for (var e = 0; e <= employee.length; e++) {

      if (e < employee.length) {
        if (e < 1) {
          this.employeeName = employee[e].employeeName
          this.employeeId = employee[e].employeeId
          var diffSplit = employee[e].busy.split("-");
          var startTime = diffSplit[0]
          var sTime = startTime.replace(":", ".")
          var endTime = diffSplit[1]
          this.previousTime = endTime;
          this.lastEndtime = endTime;
          var eTime = endTime.replace(":", ".")
          if(sTime.toString().trim() == '08.00') {
          var diff = parseFloat(eTime) - parseFloat(sTime);
          if(diff > 0) {

          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = employee[e].employeeName
          singleSlot['empId'] = employee[e].employeeId
          singleSlot['time'] = startTime + "-" + endTime
          singleSlot['status'] = "busy"
          this.allSlots.push(singleSlot)
          }
        }
        if(sTime.toString().trim() != '08.00') {

          var sTimee = '08.00';

          var diff = parseFloat(eTime) - parseFloat(sTimee);
          if(diff > 0) {

          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = employee[e].employeeName
          singleSlot['empId'] = employee[e].employeeId
          singleSlot['time'] = '08-00' + "-" + startTime
          singleSlot['status'] = "free"
          this.allSlots.push(singleSlot)

          }


          var diff = parseFloat(eTime) - parseFloat(sTime);
          if(diff > 0) {

          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = employee[e].employeeName
          singleSlot['empId'] = employee[e].employeeId
          singleSlot['time'] = startTime + "-" + endTime
          singleSlot['status'] = "busy"
          this.allSlots.push(singleSlot)
          }
        }



        } else {
          if (employee[e]) {
            var diffSplit = employee[e].busy.split("-");
            var startTime = this.previousTime
            var sTime = startTime.replace(":", ".")
            var endTime = diffSplit[0]
            var eTime = endTime.replace(":", ".")
            var diff = parseFloat(eTime) - parseFloat(sTime);

            if (diff > 0) {
              var singleSlot = {}
              var d = diff / this.percentage;
              var slotPercentage = d * 100;
              var slot = slotPercentage * 10;
              var s = slot.toFixed(2)

              singleSlot['sl'] = s
              singleSlot['empName'] = employee[e].employeeName
              singleSlot['empId'] = employee[e].employeeId
              singleSlot['time'] = startTime + "-" + endTime
              singleSlot['status'] = "free"
              this.allSlots.push(singleSlot)

            }

            var diffSplit = employee[e].busy.split("-");
            var startTime = diffSplit[0]
            var sTime = startTime.replace(":", ".")
            var endTime = diffSplit[1]
            this.previousTime = endTime;
            this.lastEndtime = endTime;
            var eTime = endTime.replace(":", ".")
            var diff = parseFloat(eTime) - parseFloat(sTime);
            var d = diff / this.percentage;
            var slotPercentage = d * 100;
            var slot = slotPercentage * 10;
            var s = slot.toFixed(2)
            var singleSlot = {}
            singleSlot['sl'] = s
            singleSlot['empName'] = employee[e].employeeName
            singleSlot['empId'] = employee[e].employeeId
            singleSlot['time'] = startTime + "-" + endTime
            singleSlot['status'] = "busy"
            this.allSlots.push(singleSlot)
          } else {
            var startTime = this.lastEndtime;
            var sTime = startTime.replace(":", ".");
            var endTime: any = this.endingTime;
            var diff = parseFloat(endTime) - parseFloat(sTime);
            var d = diff / this.percentage;
            var slotPercentage = d * 100;
            var slot = slotPercentage * 10;
            var s = slot.toFixed(2)
            var singleSlot = {}
            singleSlot['sl'] = s
            singleSlot['empName'] = this.employeeName
            singleSlot['empId'] = this.employeeId
            singleSlot['time'] = startTime + "-" + endTime
            singleSlot['status'] = "free"
            this.allSlots.push(singleSlot)
          }
        }
      } else {
        var startTime = this.lastEndtime;
        var ssTime = startTime.replace(":", ".");
        var sTime = ssTime.replace(" ", "")
        var endTime: any = this.endingTime;
        var eTime = endTime.replace(":", ".")
        if (sTime < eTime) {
          var diff = parseFloat(eTime) - parseFloat(sTime);
          var d = diff / this.percentage;
          var slotPercentage = d * 100;
          var slot = slotPercentage * 10;
          var s = slot.toFixed(2)
          var singleSlot = {}
          singleSlot['sl'] = s
          singleSlot['empName'] = this.employeeName
          singleSlot['empId'] = this.employeeId
          singleSlot['time'] = startTime + "-" + endTime
          singleSlot['status'] = "free"
          this.allSlots.push(singleSlot)
          // var extraFreeSlots=[]
          // var startDate = currentDAte + " " + startTime;
          // var endDate = currentDAte + " " + endTime;
          // const formData = new FormData();
          // formData.append('startDate', startDate);
          // formData.append('endDate', endDate);
          // this.http.post(this.url.APP_URL+"renderDates",formData).subscribe((donme: Response) => {
          //   const res = donme.json()
          //   var percentage=100/res.percentage
          //   res.data.forEach(element => {


          //     var singleSlot = {}
          //     singleSlot['sl'] = percentage
          //     singleSlot['empName'] = this.employeeName
          //     singleSlot['empId'] = this.employeeId
          //     singleSlot['time'] = element.time
          //     singleSlot['status'] = "free"
          //     extraFreeSlots.push(singleSlot)

           // });
           // console.log(extraFreeSlots)
           // this.allSlots.push(extraFreeSlots)
            //console.log(this.allSlots)
         // })
        }
      }

    }
    return this.allSlots
  }
  month_name(dt){
    var mlist = [ "Jan", "Feb", "March", "April", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec" ];
      return mlist[dt];
    };
  hou;
  min;
  pressedAgain=0;
  daySlot(index, slot,Day) {
    this.errorMessage = false;
    this.selectedItem = slot;
    this.currentDayName = Day;

    if(index === 5) {
      this.errorMessage = true;
      this.errorText = ""
      this.errorText = "Selected days are closed."
      return false;
    }


    if (this.overAllduration > 0) {

      if (slot.status == "free") {

        var time = slot.time;
        var splitTime = time.split("-")
        var startTime = splitTime[0]
        var durtion = this.overAllduration
        this.taskDate=""
        this.taskDate = this.weekDates[index]
        this.attachedUser = slot.empId

        var varDate = new Date(this.taskDate);
        var today = new Date();
        today.setHours(0,0,0,0);
        if(varDate < today) {
          this.errorMessage = true;
          this.errorText = ""
          this.errorText = "You can not select previous date slot"
        }
        var hours: any = durtion / 60;
        if (hours.toString().indexOf(".") !== -1) {
          var ho = hours.toString().split(".");
          this.hou = ho[0]
          this.min = ho[1]
        } else {
          this.hou = hours
        }
        var hoursSplit = startTime.split(":")
        var h = hoursSplit[0]
        var min = hoursSplit[1]
        var fHpours = parseFloat(h) + parseFloat(this.hou)
        var Minutes = hours * 60;

        if (Minutes > 60) {
          var fMin = Minutes - 60;
        } else {
          var fMin = Minutes;
        }

        if (fMin == 60) {
          var mints = "00:00";
        } else {
          var mints = fMin.toString() + ":00";
        }
        if (fHpours < 10) {
          var hrs = "0" + fHpours
        } else {
          var hrs = fHpours.toString();
        }
        var endDate =  moment.utc(startTime.toString().trim(),'H:mm').add(durtion,'minutes').format('HH:mm:ss');
        var endSplit = endDate.toString().replace(":",".");
        var eTime = "16.00";
        if(endSplit > eTime) {
          $("html, body").animate({ scrollTop: 0 }, "slow");
          this.errorMessage = true;
          this.errorText = ""
          this.errorText = "Slot time is less than selected material time. Please select any other slot."

        }
        this.taskTime = startTime.toString().trim() + ":00" + " - " + endDate
        this.fromStart = ""
        this.fromEnd = ""
        this.fromStart = startTime.toString().trim() + ":00";
        this.fromEnd = endDate;

        //checks for change
        var changeTimeStart = startTime.toString().trim().replace(":",".");
        var diff = changeTimeStart - this.startingTime;
        if(this.finalHours > this.threshold) {

        }
        var cancellationPrice : any =300;
        if(this.finalHours < this.threshold) {

          if(this.finalHours < 0) {

            this.errorMessage = true;
            this.errorText = "You are cancelling booking for previous time. Cancellation fee will be applied"
            this.price = parseInt(this.overAllPrice.toString()) + parseInt(cancellationPrice);

              $("html, body").animate({ scrollTop: 0 }, "slow");

          }
          if(this.finalHours >= 0 && this.finalHours <= 2) {
          //  console.log("b")
            this.errorMessage = true;
            this.errorText = "Cancellation Fee will be applied."
            this.price = parseInt(this.overAllPrice.toString()) + parseInt(cancellationPrice);
          }
        }
        if(this.finalHours > 2) {
          this.overAllPrice = this.overAllPrice;
        }
        if(this.pressedAgain == 0 && this.finalHours < 0 ) {
          this.overAllPrice = this.price
        }
        if(this.pressedAgain == 0 && this.finalHours >= 0 && this.finalHours <= 2 ) {
          this.overAllPrice = this.price
        }
        if(this.pressedAgain > 0) {
         var p = this.price - cancellationPrice;
          this.overAllPrice = p;
        }
        this.pressedAgain++;

      } else {
        $("html, body").animate({ scrollTop: 0 }, "slow");
        this.errorMessage = true;
        this.errorText = ""
        this.errorText = "Please select a free time slot"
      }
    }
    else {

      this.errorMessage = true;
      this.errorText = ""
      this.errorText = "Please Select any material first"
    }
  }
    reschedule() {
      if(this.errorMessage == false) {
      const formData = new FormData()
      formData.set("bookingId",this.bookingId)
      formData.set("projectId",this.projectId)
      formData.set("userId",this.userId)
      if(this.attachedUser != "") {
        formData.set("attachedUser",this.attachedUser)
      } else {
        formData.set("attachedUser",this.attachUserDB)
      }
      formData.append('start_date', this.taskDate + " " + this.fromStart);
      formData.append('end_date', this.taskDate + " " + this.fromEnd);
      formData.append('bDate', this.taskDate + " " + this.fromStart + "-" + this.fromEnd);
      formData.append('price', this.overAllPrice.toString());

      this.spinner.show();
      this.http.post(this.url.APP_URL+ "changeBooking",formData)
      .subscribe((data: Response) => {
       const d = data.json();
       if (d.status == "success") {
         var _this = this;
         setTimeout(function(){
           _this.spinner.hide()
           _this.router.navigate(['/'])
          }, 3000);

       }
     })
    } else {
      $("html, body").animate({ scrollTop: 0 }, "slow");
      this.errorMessage = true;
      this.errorText = "Select a free slot."
    }
    }
    nextDate;
    previous() {
      if(this.currentValue == 0) {
        this.errorMessage=true;
        this.errorText = "You can not go back from to previous date slots"
      }
      if(this.currentValue > 0) {

        this.errorMessage=false;
        this.currentValue = this.currentValue-1;

        if(this.dateToAddOrSubtract > 7) {
          this.dateToAddOrSubtract = this.dateToAddOrSubtract - 7;
        }
        if(this.dateToAddOrSubtract == 7) {
          this.dateToAddOrSubtract = 7;
        }
        this.plannings=[]
        this.installerNames=[]
        this.weekDates=[]
        this.installers=[]
        this.singleDateData = []
        this.all=[]
        this.finalSlots=[]
        this.day1=[]
        this.day2=[]
        this.day3=[]
        this.day4=[]
        this.day5=[]
        this.day6=[]
        this.allSlots=[]
        this.weekDatesWithDate=[]

        var params = "?autoDealerId=" + this.mobilPlanId+"&incValue="+this.dateToAddOrSubtract+"&type=previous&date="+this.nextDate;
        this.spinner.show()
        this.http.get(this.url.APP_URL + "planningnextprevious" + params).subscribe((data: Response) => {
            const d = data.json();
            if (d.status == "success") {
              this.plannings = d.data;
              this.installers = d.installers;
              this.weekDates = d.dates;
              this.installerNames = d.installerNames;
              this.weekDatesWithDate= d.datesWithNames;
              this.nextDate=this.weekDates[0]

              for (var a = 0; a < this.weekDates.length; a++) {
                this.singleDateData = this.plannings[this.weekDates[a]];
                this.j = 0;
                var x = 0;
                this.installers.forEach(element => {
                  if (this.singleDateData[element]) {
                    this.all[x] = this.makeSlots(this.singleDateData[element],this.weekDates[a]);
                  } else {
                    if (a < 5) {
                      var completeDatSlot=[]
                       var startDate = this.weekDates[a] + " " + "08:00";
                    var endDate = this.weekDates[a] + " " + "16:00";
                    const formData = new FormData();
                    formData.append('startDate', startDate);
                    formData.append('endDate', endDate);
                    this.http.post(this.url.APP_URL+"renderDates",formData).subscribe((donme: Response) => {
                      const res = donme.json()
                      var percentage = 100/res.percentage;
                      res.data.forEach(element1 => {
                        var singleSlot = {}
                        singleSlot['sl'] = percentage
                        singleSlot['empName'] = this.employeeName
                        singleSlot['empId'] = element
                        singleSlot['time'] = element1.time
                        singleSlot['status'] = "free"
                        completeDatSlot.push(singleSlot)
                      });
                    })
                    this.all[x] = completeDatSlot;
                    }
                  }
                  x++;
                });
                this.finalSlots[a] = this.all
                this.all = []
              }
              var obj = {}
              obj['status'] = "closed"
              this.finalSlots[5] = obj
              this.finalSlots[6] = obj
              this.day1 = this.finalSlots[0]
              this.day2 = this.finalSlots[1]
              this.day3 = this.finalSlots[2]
              this.day4 = this.finalSlots[3]
              this.day5 = this.finalSlots[4]
             this.spinner.hide()
            }
          })
      }
    }

    next() {
      this.errorMessage=false;
      this.currentValue++;
      this.dateToAddOrSubtract = this.dateToAddOrSubtract + 7;
      this.plannings=[]
      this.installerNames=[]
      this.weekDates=[]
      this.installers=[]
      this.singleDateData = []
      this.all=[]
      this.finalSlots=[]
      this.day1=[]
      this.day2=[]
      this.day3=[]
      this.day4=[]
      this.day5=[]
      this.day6=[]
      this.allSlots=[]
      this.weekDatesWithDate=[]

      var params = "?autoDealerId=" + this.mobilPlanId+"&incValue="+this.dateToAddOrSubtract+"&type=next&date=''";
      this.spinner.show()
      this.http.get(this.url.APP_URL + "planningnextprevious" + params).subscribe((data: Response) => {
          const d = data.json();
          if (d.status == "success") {
            this.plannings = d.data;
            this.installers = d.installers;
            this.weekDates = d.dates;
            this.weekDatesWithDate= d.datesWithNames;
            this.nextDate=this.weekDates[0]
            this.installerNames = d.installerNames;
            for (var a = 0; a < this.weekDates.length; a++) {
              this.singleDateData = this.plannings[this.weekDates[a]];
              this.j = 0;
              var x = 0;
              this.installers.forEach(element => {
                if (this.singleDateData[element]) {
                  this.all[x] = this.makeSlots(this.singleDateData[element],this.weekDates[a]);
                } else {
                  if (a < 5) {
                    var completeDatSlot=[]
                     var startDate = this.weekDates[a] + " " + "08:00";
                  var endDate = this.weekDates[a] + " " + "16:00";
                  const formData = new FormData();
                  formData.append('startDate', startDate);
                  formData.append('endDate', endDate);
                  this.http.post(this.url.APP_URL+"renderDates",formData).subscribe((donme: Response) => {
                    const res = donme.json()
                    var percentage = 100/res.percentage;
                    res.data.forEach(element => {
                      var singleSlot = {}
                      singleSlot['sl'] = percentage
                      singleSlot['empName'] = this.employeeName
                      singleSlot['empId'] = this.employeeId
                      singleSlot['time'] = element.time
                      singleSlot['status'] = "free"
                      completeDatSlot.push(singleSlot)
                    });
                  })
                  this.all[x] = completeDatSlot;
                  }
                }
                x++;
              });
              this.finalSlots[a] = this.all
              this.all = []
            }
            var obj = {}
            obj['status'] = "closed"
            this.finalSlots[5] = obj
            this.finalSlots[6] = obj
            this.day1 = this.finalSlots[0]
            this.day2 = this.finalSlots[1]
            this.day3 = this.finalSlots[2]
            this.day4 = this.finalSlots[3]
            this.day5 = this.finalSlots[4]
           this.spinner.hide()
          }
        })

    }

}
