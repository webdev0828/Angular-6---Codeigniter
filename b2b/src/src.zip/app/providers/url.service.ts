import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UrlService {
  APP_URL = '';
  SOLFILM_URL = '';
  constructor() {
   this.APP_URL = "http://localhost/b2b/api/";
   this.SOLFILM_URL = "http://localhost/b2b/solfilm/";
    //this.APP_URL = "http://kycagency.com/b2bapi/api/";
   // this.SOLFILM_URL = "http://kycagency.com/b2bapi/solfilm/";
   }
}
