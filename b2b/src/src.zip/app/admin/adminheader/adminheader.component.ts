import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';
import { AuthService } from 'src/app/providers/auth.service';
@Component({
  selector: 'app-adminheader',
  templateUrl: './adminheader.component.html',
  styleUrls: ['./adminheader.component.css']
})
export class AdminheaderComponent implements OnInit {
  userType;
  uType = ""
  isLoggedIn = false;
  constructor(private location: Location, private router : Router, public auth : AuthService) {
    if(auth.getLocalTokens() != null){
      this.uType = JSON.parse(localStorage.getItem("data")).accountType;
    }
  }

  ngOnInit() {
  }
  logout() {
    this.auth.loggedIn = false
    this.auth.clearLocalTokens();
    this.router.navigate(['/login'])
  }
}
