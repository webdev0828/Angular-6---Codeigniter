import { Component, OnInit } from '@angular/core';
import { AuthService } from '../providers/auth.service';
import { Router } from '@angular/router';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { UrlService } from '../providers/url.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-useradmin',
  templateUrl: './useradmin.component.html',
  styleUrls: ['./useradmin.component.css']
})
export class UseradminComponent implements OnInit {
  uType = ""
  autoDealers = [];
  alertText = "";
  alertShow = false;
  alertShowDeactive = false;
  alertTextDeactive = "";
  allEmployees = [];
  employees = []
  all = false;
  assigned = false;
  noAssigned = false;
  AssignedText = ""
  Assigned = false;
  customerId = "";
  customerEmail = "";
  noAssignedText = ""
  customerName = ""
  loginError = false
  loginErrorText = ""
  constructor(private auth: AuthService, private router: Router, private http: Http, private url: UrlService,
    private spinner: NgxSpinnerService) {
    if (auth.getLocalTokens() != null) {
      this.uType = JSON.parse(localStorage.getItem("data")).accountType;
    }
    if (auth.loggedIn && this.uType == "admin") {
      var passwordChanged = JSON.parse(localStorage.getItem("data")).passwordChanged;
      if (passwordChanged == "no") {
        this.router.navigate(['/changepassword']);
      }
    } else {
      this.router.navigate(['/login']);
    }
  }
  ngOnInit() {
    this.spinner.show();
    this.http.get(this.url.SOLFILM_URL + "customers")
      .subscribe((data: Response) => {
        const response = data.json();
        if (response.status == "success") {
          this.autoDealers = response.data;
          this.http.get(this.url.APP_URL + "Savedemployees")
            .subscribe((data: Response) => {
              this.spinner.hide();
              this.all = true;
              this.assigned = false;
              const res = data.json();
              if (res.status == "success") {
                this.employees = res.data;
                this.allEmployees = this.employees;
                this.allEmployees.reverse()
              }
            })
        }

      })
  }

  grantAccess(value) {
    this.alertShow = false;
    this.alertText = "";
    var checkValue = value.split("_");
    var email = checkValue[1];
    var status = checkValue[0];
    var mobilPlanId = checkValue[2];
    var name = checkValue[3];
    if (status == "active") {
      if (confirm("Are you sure to activate this user ")) {
        const formData = new FormData();
        formData.append('email', email);
        formData.append('status', status);
        formData.append('mobilPlanId', mobilPlanId);
        formData.append('name', name);
        this.http.post(this.url.APP_URL + 'addUser', formData)
          .subscribe((statusChanged: Response) => {
            const response = statusChanged.json();
            if (response.status == "success") {
              if (response.type == "active") {
                this.alertShow = true;
                this.alertShowDeactive = false;
                this.alertText = response.data;
                this.http.get(this.url.SOLFILM_URL + "customers")
                  .subscribe((data: Response) => {
                    const response = data.json();
                    if (response.status == "success") {
                      this.autoDealers = []
                      this.autoDealers = response.data;
                    }
                  });
              }
              if (response.type == "disable") {
                this.alertShow = false;
                this.alertShowDeactive = true;
                this.alertTextDeactive = response.data;
                this.http.get(this.url.SOLFILM_URL + "customers")
                  .subscribe((data: Response) => {
                    const response = data.json();
                    if (response.status == "success") {
                      this.autoDealers = []
                      this.autoDealers = response.data;
                    }
                  });
              }

            }
          });
      }
    } else {
      if (confirm("Are you sure to deactivate this user ")) {
        const formData = new FormData();
        formData.append('email', email);
        formData.append('status', status);
        formData.append('mobilPlanId', mobilPlanId);
        formData.append('name', name);
        this.http.post(this.url.APP_URL + 'addUser', formData)
          .subscribe((statusChanged: Response) => {
            const response = statusChanged.json();
            if (response.status == "success") {
              if (response.type == "active") {
                this.alertShow = true;
                this.alertShowDeactive = false;
                this.alertText = response.data;
                this.http.get(this.url.SOLFILM_URL + "customers")
                  .subscribe((data: Response) => {
                    const response = data.json();
                    if (response.status == "success") {
                      this.autoDealers = []
                      this.autoDealers = response.data;
                    }
                  });
              }
              if (response.type == "disable") {
                this.alertShow = false;
                this.alertShowDeactive = true;
                this.alertTextDeactive = response.data;
                this.http.get(this.url.SOLFILM_URL + "customers")
                  .subscribe((data: Response) => {
                    const response = data.json();
                    if (response.status == "success") {
                      this.autoDealers = []
                      this.autoDealers = response.data;
                    }
                  });
              }
            }

          });
      }
    }
  }

  loadData() {
    this.autoDealers = []
    this.http.get(this.url.SOLFILM_URL + "customers")
      .subscribe((data: Response) => {
        const response = data.json();
        if (response.status == "success") {
          this.autoDealers = response.data;
        }

      })
  }

  getAssignedInstallers(value) {
    if (value != "") {
      var ChangeValue = value.split("_");
      var email = ChangeValue[1];
      var customerId = ChangeValue[0];
      var name = ChangeValue[2];
      this.customerName = name;
      this.all = false;
      this.Assigned = false;
      this.AssignedText = ""
      this.assigned = true;
      this.noAssigned = false;
      this.customerId = "";
      this.customerEmail = ""
      this.customerId = customerId;
      this.customerEmail = email;
      this.spinner.show();
      var params = "?customerId=" + customerId;
      this.http.get(this.url.APP_URL + "employees" + params)
        .subscribe((data: Response) => {
          const res = data.json();
          this.spinner.hide();
          if (res.status == "success") {
            this.noAssigned = false;
            this.employees = [];
            this.employees = res.data;
            this.employees.reverse()
          }
          if (res.status == "failed") {
            this.noAssigned = true;
            this.noAssignedText = "";
            this.noAssignedText = "No Employee has been assigned to this customer yet."
            this.all = true;
            this.assigned = false;
            this.employees = []
            this.employees = this.allEmployees;
            this.employees.reverse()
          }
        })
    } else {
      this.noAssigned = false;
      this.all = true;
      this.assigned = false;
      this.employees = [];
      this.employees = this.allEmployees;
    }
  }

  assignEmployee(value) {
    if (this.customerId != "") {
      var assignValue = value.split("_");
      var status = assignValue[0];
      var employeeId = assignValue[1];

      const formData = new FormData();
      formData.append('status', status);
      formData.append('mobilPlanId', employeeId);
      formData.append('customerId', this.customerId);
      formData.append('email', this.customerEmail);
      this.http.post(this.url.APP_URL + "assignEmployee", formData)
        .subscribe((data: Response) => {
          const response = data.json();
          this.employees = [];
          if (response.status == "success") {
            this.employees = response.data;
            console.log(this.employees)
            this.Assigned = true;
            this.AssignedText = response.message;
          } else {
            this.noAssigned = true;
            this.employees = []
            this.employees = this.allEmployees
            this.noAssignedText = "";
            this.noAssignedText = response.data;
          }
        })

    } else {
      this.noAssigned = true;
      this.employees=[]
      this.employees = this.allEmployees
      this.noAssignedText = "";
      this.noAssignedText = "Please select an employee First"
    }
  }

  LoginAsAutoDealer(userEmail) {
    this.loginError = false
    this.loginErrorText = ""
    const formData = new FormData();
    formData.append('email', userEmail);
    this.http.post(this.url.APP_URL + "simulateUser", formData)
      .subscribe((data: Response) => {
        const response = data.json()
        if (response.status == "success") {
          this.auth.saveGrantAccessToAdmin(response.data.userId, response.data.name, response.data.email, response.token, response.data.passwordChanged,response.data.mobilPlanId);
          this.router.navigate(["/stepper"]);
        }
        if (response.status == "failed") {
          this.loginError = true
          this.loginErrorText = ""
          this.loginErrorText = response.data
        }
      })
  }

}
