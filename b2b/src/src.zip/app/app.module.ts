import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { OrderComponent } from './order/order.component';
import { LoginComponent } from './login/login.component';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { EmployeesComponent } from './employees/employees.component';
import { ForgotpasswordComponent } from './forgotpassword/forgotpassword.component';
import { OrderconfirmationComponent } from './orderconfirmation/orderconfirmation.component';
import { OrdercustomComponent } from './ordercustom/ordercustom.component';
import { OrdercustomdialogComponent } from './ordercustomdialog/ordercustomdialog.component';
import { OrderlistComponent } from './orderlist/orderlist.component';
import { OrderschedualComponent } from './orderschedual/orderschedual.component';
import { RatesComponent } from './rates/rates.component';
import { UseradminComponent } from './useradmin/useradmin.component';
import { ValidationComponent } from './validation/validation.component';
import { StepperComponent } from './stepper/stepper.component';
import { AdminheaderComponent } from './admin/adminheader/adminheader.component';
import {NgbModal, ModalDismissReasons, NgbModalModule} from '@ng-bootstrap/ng-bootstrap';
import { HashLocationStrategy, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { FormsModule,FormGroup, FormBuilder, Validators } from '@angular/forms';
import { EmailtemplateComponent } from './emailtemplate/emailtemplate.component';
import { ApiService } from './providers/api.service';
import { AuthService } from './providers/auth.service';
import { UrlService } from './providers/url.service';
import {HttpModule} from '@angular/http';
import { HttpClientModule  } from '@angular/common/http';
import { NgxSpinnerModule } from 'ngx-spinner';
import { RescheduleComponent } from './reschedule/reschedule.component';
import { ForgetComponent } from './forget/forget.component';
import * as $ from 'jquery';
@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    OrderComponent,
    LoginComponent,
    ChangePasswordComponent,
    EmployeesComponent,
    ForgotpasswordComponent,
    OrderconfirmationComponent,
    OrdercustomComponent,
    OrdercustomdialogComponent,
    OrderlistComponent,
    OrderschedualComponent,
    RatesComponent,
    UseradminComponent,
    ValidationComponent,
    StepperComponent,
    AdminheaderComponent,
    EmailtemplateComponent,
    RescheduleComponent,
    ForgetComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModalModule,
    FormsModule,
    HttpModule,
    HttpClientModule,
    NgxSpinnerModule
  ],
  providers: [ApiService, AuthService,UrlService,
    {provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
