import { Component, OnInit } from '@angular/core';
import { AuthService } from '../providers/auth.service';
import { Router } from '@angular/router';
import { UrlService } from '../providers/url.service';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-rates',
  templateUrl: './rates.component.html',
  styleUrls: ['./rates.component.css']
})
export class RatesComponent implements OnInit {
  uType=""
  rates=[]
  threshold=[]
  calloutFee;
  secondaryCallout;
  cancellation;
  lateCallOut;
  lateCancellation;
  successMessage=false;
  successText=""
  constructor(private auth : AuthService, private router : Router, private url : UrlService, private http : Http) {
    if(auth.getLocalTokens() != null){
      this.uType = JSON.parse(localStorage.getItem("data")).accountType;
    }
    if(auth.loggedIn && this.uType == "admin") {
      var passwordChanged = JSON.parse(localStorage.getItem("data")).passwordChanged;
      if(passwordChanged == "no") {
        this.router.navigate(['/changepassword']);
      }
    } else {

      this.router.navigate(['/login']);
    }
   }

  ngOnInit() {
    this.http.get(this.url.APP_URL + "rates")
      .subscribe((data: Response) => {
        const d = data.json();
        if (d.status == "success") {
          this.rates = d.data;
          this.calloutFee = this.rates[0].calloutFee
          this.secondaryCallout = this.rates[0].secondaryCallout
          this.cancellation = this.rates[0].cancellation
          this.lateCallOut = this.rates[0].lateCallOut
          this.lateCancellation = this.rates[0].lateCancellation
        }
      })
  }
  ratesSave(form) {
    const formData = new FormData();
    formData.append('calloutFee', this.calloutFee);
    formData.append('secondaryCallout', this.secondaryCallout);
    formData.append('cancellation', this.cancellation);
    formData.append('lateCallOut', this.lateCallOut);
    formData.append('lateCancellation', this.lateCancellation);
    this.http.post(this.url.APP_URL + 'rates', formData)
    .subscribe((registered: Response) => {
      const response = registered.json();
      if(response.status == "success") {
        this.successMessage=true;
        this.successText="Rates Updated successfully"
        var _this=this;
        setTimeout(function(){
          location.reload()
          }, 1000);

      }

    });

  }

}
