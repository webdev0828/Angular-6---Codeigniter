import { Component, OnInit } from '@angular/core';
import { AuthService } from '../providers/auth.service';
import { Router } from '@angular/router';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { UrlService } from '../providers/url.service';
import { ApiService } from '../providers/api.service';


@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  email;
  emailErrorDiv=false;
  emailErrorMessage = ""
  emailSuccess=false;
  successMessageText = ""
  emailError=false;
  constructor(private api: ApiService,private router : Router,private url : UrlService, private http : Http) { }

  ngOnInit() {

  }

  changePassword(form : any) {
    if(this.emailError == false && form.email != "") {
      this.emailErrorDiv = false;
      const formData = new FormData();
      formData.set("email",form.email)
      this.http.post(this.url.APP_URL+"forgetPassword",formData)
      .subscribe((registered: Response) => {
        const response = registered.json();
        if(response.status == "success") {
          this.emailSuccess = true;
          this.successMessageText = "Email sent Successfully"
        } else {
          this.emailErrorDiv = true;
          this.emailErrorMessage = "Invalid Email"
        }
      });
    } else {
      this.emailErrorDiv = true;
      this.emailErrorMessage = "Provide Email"
    }

  }

  validateEmail(email) {
    if (email == "") {
      this.emailError = false;
    } else {
      var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

      if (re.test(String(email).toLowerCase()) == false) {
        this.emailError = true;

      } else {
        this.emailError = false;
      }
    }
  }

}
