import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-emailtemplate',
  templateUrl: './emailtemplate.component.html',
  styleUrls: ['./emailtemplate.component.css']
})
export class EmailtemplateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
