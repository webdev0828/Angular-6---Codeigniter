import { Component, OnInit } from '@angular/core';
import { AuthService } from '../providers/auth.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Http, Headers, Response, RequestOptions } from '@angular/http';
import { UrlService } from '../providers/url.service';
import { ApiService } from '../providers/api.service';

@Component({
  selector: 'app-forget',
  templateUrl: './forget.component.html',
  styleUrls: ['./forget.component.css']
})
export class ForgetComponent implements OnInit {

  uType = ""
  passwordChanged = false;
  newPassword = "";
  confNewPassword = "";
  passwordError = false;
  newPasswordError = false;
  passwordMismatchError = false;
  passwordErrortext = "";
  passwordChangedText = "";
  passwordChangeStatus = false;
  userEmail;
  emailErrorDiv=false;
  emailErrorMessage=""
  constructor(private auth : AuthService, private router : Router,private url : UrlService, private http : Http,
    private route : ActivatedRoute) {

      this.route.params.subscribe( params => {
        this.userEmail = params.id;
      });

  }

  ngOnInit() {
    const formData = new FormData();
    formData.set("email",this.userEmail)
    this.http.post(this.url.APP_URL+"checkEmail",formData)
    .subscribe((registered: Response) => {
      const response = registered.json();
      if(response.status == "failed") {
        this.emailErrorDiv = true;
        this.emailErrorMessage = "Email does not exist"
      } else {

      }
    });
  }

  ResetPassword(form : any) {
    this.passwordChanged = false;
    if(form.newPassword === '' || form.confNewPassword === '') {
      this.passwordMismatchError = true;
      this.passwordErrortext = "";
      this.passwordErrortext = "Fill in required fields";
    }
   else if(this.passwordError == true || this.newPasswordError == true) {
      this.passwordMismatchError = true;
      this.passwordErrortext = "";
      this.passwordErrortext = "Password length for both should be minimum 6";
    } else if(form.newPassword != form.confNewPassword) {
      this.passwordMismatchError = true;
      this.passwordErrortext = "";
      this.passwordErrortext = "Passwords does not match";
    } else {
      const formData = new FormData();
      formData.append('email', this.userEmail);
      formData.append('password', form.newPassword);
      this.http.post(this.url.APP_URL + 'passwordForget', formData)
      .subscribe((registered: Response) => {
        const response = registered.json();
        if(response.status == "success") {
          this.passwordMismatchError = false;
          this.passwordChangeStatus = true;

          this.passwordChangedText = "Password reset successful. Login now with new password";
        }
        if(response.status == "failed") {
          this.passwordChangeStatus = false;
          this.passwordMismatchError = true;
          this.passwordErrortext = "";
          this.passwordErrortext = response.message;
        }

      });

    }

  }

  passwordChange(value) {
    if (value == "") {
    } else {
      if (value.length < 7) {
        this.passwordError = true;
      } else {
        this.passwordError = false;
      }
    }
  }

  passwordChange1(value) {
    if (value == "") {
    } else {
      if (value.length < 7) {
        this.newPasswordError = true;
      } else {
        this.newPasswordError = false;
      }
    }
  }

}
