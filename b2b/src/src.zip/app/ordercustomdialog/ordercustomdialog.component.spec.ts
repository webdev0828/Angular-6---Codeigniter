import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrdercustomdialogComponent } from './ordercustomdialog.component';

describe('OrdercustomdialogComponent', () => {
  let component: OrdercustomdialogComponent;
  let fixture: ComponentFixture<OrdercustomdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrdercustomdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrdercustomdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
